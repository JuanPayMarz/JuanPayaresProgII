vuelo = {
"Aerolinea": "LATAM AIRLANES",
"Vuelo": "AV702",
"Origen": "CARTAGENA",
"Destino": "USA",
"Tipo_Maleta": ['Cabina', 'Mano', 'Bodega']
}

print("Valores del diccionario:")
for key, value in vuelo.items():
    print(f"{key}: {value}")

print("\nValores de tipo de maleta:")
for maleta in vuelo["Tipo_Maleta"]:
    print(maleta)