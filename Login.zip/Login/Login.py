import tkinter as tk

ventana = tk.Tk()
ventana.title("Inicio de Sesión")

frame_izquierdo = tk.Frame(ventana, width=200, height=200, bg="white")
frame_izquierdo.pack(side=tk.LEFT, fill=tk.Y)

logo_image = tk.PhotoImage(imagen="w.png")
logo_label = tk.Label(frame_izquierdo, image=logo_image)
logo_label.pack(pady=20)

frame_derecho = tk.Frame(ventana, bg="lightgrey")
frame_derecho.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

titulo_label = tk.Label(frame_derecho, text="Inicio de Sesión", font=("Arial", 18), bg="lightgrey")
titulo_label.pack(pady=20)

usuario_label = tk.Label(frame_derecho, text="Usuario:", font=("Arial", 12), bg="lightgrey")
usuario_label.pack()
usuario_entry = tk.Entry(frame_derecho, font=("Arial", 12))
usuario_entry.pack(pady=5)

clave_label = tk.Label(frame_derecho, text="Clave:", font=("Arial", 12), bg="lightgrey")
clave_label.pack()
clave_entry = tk.Entry(frame_derecho, show="*", font=("Arial", 12))
clave_entry.pack(pady=5)

def ingresar():
    pass

boton_ingresar = tk.Button(frame_derecho, text="Ingresar", font=("Arial", 12), command=ingresar)
boton_ingresar.pack(pady=20)

ventana.mainloop()
